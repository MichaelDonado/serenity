import 'package:flutter/material.dart';

// identificador de camara

class Vehicle {
  final String plate;
  final String ownerName;

  Vehicle(this.plate, this.ownerName);
}

List<Vehicle> registeredVehicles = [];

class VerifyAccessScreen extends StatefulWidget {
  @override
  _VerifyAccessScreenState createState() => _VerifyAccessScreenState();
}

class _VerifyAccessScreenState extends State<VerifyAccessScreen> {
  void checkAccess(String plate) {
    Vehicle matchingVehicle = registeredVehicles.firstWhere(
      (vehicle) => vehicle.plate == plate,
      orElse: () => null,
    );

    if (matchingVehicle != null) {
      // Mostrar el nombre del propietario y permitir el acceso.
    } else {
      accessDenied(plate);
    }
  }

  void accessDenied(String plate) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Acceso denegado'),
          content: Text('La placa $plate no está autorizada.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Cierra la alerta
              },
              child: Text('Aceptar'),
            ),
          ],
        );
      },
    );
  }
}
